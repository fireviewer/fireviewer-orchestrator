"""Versioned FireViewer component."""
